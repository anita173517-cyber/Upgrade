# Media3 Pro, OkHttp, Glide & Security Crypto Optimization Rules for Small APK Size
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**
-keep class com.harindra.iptvpro.** { *; }
-keepattributes Signature, InnerClasses, EnclosingMethod
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn com.google.crypto.tink.**
-keep public class * implements com.bumptech.glide.module.GlideModule
-keep class * extends com.bumptech.glide.module.AppGlideModule {
    <init>(...);
}
